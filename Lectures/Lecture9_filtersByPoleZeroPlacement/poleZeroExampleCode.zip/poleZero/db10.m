function y = db10(x)
% function y = db10(x)

x = squeeze(x);
y = 10*log10(abs(x)+.1);
