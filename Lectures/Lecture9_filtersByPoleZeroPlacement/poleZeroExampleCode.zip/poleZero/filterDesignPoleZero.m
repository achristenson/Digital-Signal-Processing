function [b,a]= filterDesignPoleZero(zeros,poles,Fs,G)
% function [b,a]= filterDesignPoleZero(zeros,poles,Fs,G)
% given a vector of poles and zeros, this function 
% a) plots the pole/zero diagram, magnitude, phase, and group delay
% b) returns the filter coefficients b and a
% Fs is sample rate: if only 2 input args, defaults to 1000 Hz
% G is gain: if only 3 input args, defaults to 1

if nargin<3
    Fs=1000; 
end
if nargin<4,
    G = 1; % unit gain by default
end
zeros = zeros(:);  % make sure 
poles = poles(:);

subplot(221)
zplane(zeros,poles);

npts=1001;
omegaVec = linspace(-pi,pi,npts);
expTerm = exp(j*omegaVec);
num = (expTerm-zeros(1)).*(expTerm-zeros(2));
denom = (expTerm-poles(1)).*(expTerm-poles(2));
H = G*num./denom;



Hmag = abs(H).^2;
Hph = angle(H);%unwrap(angle(H));
[b,a]=zp2tf(zeros,poles,G);
[Gd,fgd]=grpdelay(b,a,npts,Fs);

freq = (Fs/2)*omegaVec./(pi);
subplot(222), plot(freq,db10(Hmag))
grid on
xlabel('Frequency, Hz (Fs=1kHz)')
ylabel('|H|^2, dB')
subplot(223), plot(freq,Hph)
grid on
xlabel('Frequency, Hz')
ylabel('phase(H),radians')
subplot(224), plot(fgd,Gd)
grid on
xlabel('Frequency, Hz')
ylabel('grd(H), samples')
xlim([0 fgd(end)])
boldify


