
%% bandpass filter, zeros at origin


p = .7;
poles = [0 p];
zer = [0 1/p] ;

figure(99)
[b,a]=filterDesignPoleZero(zer,poles);

% set up a sine burst signal
nsamp=200/4;
Fs=1000;
f0 = 110;
signal=zeros(1,1001);
if 1
    signal(11:10+nsamp) = sin(2*pi*f0/Fs*(1:nsamp));
else
    t=(1:nsamp)/Fs;
    %signal(11:10+nsamp) = sin(2*pi*f0/Fs*(1:nsamp)) + sin(2*pi*(f0+20)/Fs*(1:nsamp));
    signal(11:10+nsamp) = chirp(t,70,t(end),150);
end

% get frequency spectrum of the signal
[X,f]=ctft(signal,Fs);

% filter the signal
y=filter(b,a,signal);

figure(100),

subplot(311), plot(signal)
xlim([-nsamp/5 nsamp*1.5])
title('input signal')
xlabel('Time, samples')
subplot(312), plot(f,abs(X))
%xlim([0 Fs/2])
title('input signal spectrum')

xlabel('Frequency, Hz (Fs=1kHz')
subplot(313), plot(y)
title('output signal')
xlim([-nsamp/5 nsamp*1.5])
xlabel('Time, samples')
boldify


%% noise example

noise = randn(1,1000);

% get frequency spectrum of the noise
[W,f]=ctft(noise,Fs);

% filter the signal
noiseFilt=filter(b,a,noise);
[Wfilt,f]=ctft(noiseFilt,Fs);

figure,

subplot(221), plot(noise)
title('input noise')
xlabel('Time, samples')
subplot(223), plot(f,abs(W))
%xlim([0 Fs/2])
title('input noise spectrum')

subplot(222), plot(noiseFilt)
title('filtered noise')
xlabel('Time, samples')
subplot(224), plot(f,abs(Wfilt))
%xlim([0 Fs/2])
title('filtered noise spectrum')

xlabel('Time, samples')
boldify
