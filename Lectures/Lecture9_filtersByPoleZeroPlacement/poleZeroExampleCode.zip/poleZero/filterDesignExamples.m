
%% digital resonator filter, zeros at origin

zeros = [0 0];  % zeros at origin

% conjugate-symmetric pair of poles
omega=pi/5;  
r = .9;
poles = r*[exp(-j*omega) exp(j*omega)];

filterDesignPoleZero(zeros,poles); % assumes Fs=1 kHz, G = 1

%% we can adjust gain as desired....
Fs = 1000;
G = 0.105;  % calculate this by setting constraint on H(omega)
filterDesignPoleZero(zeros,poles,Fs,G);

%% single-pole complex filter 
%(to show effects of pole in isolation)

zeros = [0 0 ];  % zeros at origin

% take one pole from above
r=.9;
omega=pi/5;  
poles = r*[exp(-j*omega) 0 ];

filterDesignPoleZero(zeros,poles);
subplot(224),h=plot(NaN); title('Matlab grpdelay does not work here')

%% bandpass filter, zeros at z=+/-1

zeros = [-1 1];  % zeros 

% conjugate-symmetric pair of poles
omega=pi/5;  
r = .3;
poles = r*[exp(-j*omega) exp(j*omega)];

filterDesignPoleZero(zeros,poles);

%% notch filter, zeros only (poles at origin)

% conjugate-symmetric pair of zeros on unit circle
Fs = 500;
fcut=60;
omega= fcut*(2*pi/Fs);  % if Fs=500, design to kill 60 Hz
r = 1;
zeros = r*[exp(-j*omega) exp(j*omega)];

poles = [0 0];  % poles at origin

filterDesignPoleZero(zeros,poles,Fs);

% we could adjust gain... but if we want H(omega)=1 at both 
% zero freq and high freq, we are stuck!

%% notch filter, zeros and poles at freq of interest

% conjugate-symmetric pair of zeros on unit circle
omega0= 60*(2*pi/Fs);  % if Fs=1000, design to kill 60 Hz
rz = 1;
zeros = rz*[exp(-j*omega0) exp(j*omega0)];

rp=0.95;
poles = rp*[exp(-j*omega0) exp(j*omega0)];

filterDesignPoleZero(zeros,poles,Fs);

% what should G be, to get unit gain at omega = 0?  this is a HW problem

%% comb filter,
clear a b zeros
pad = [];
%pad = 0;
%pad = [ 0 0 0 ];
%pad=[0 0 0 0 0 0 0 ];
b = [1 pad 1 pad 1 pad 1 pad 1 pad  1 pad  1];

a = zeros(size(b));
a(1)=1;  % a0=1, all other terms = 0

% convert to zero/poles
[zer,poles]=tf2zp(b,a);

% here, can't use filterDesignPoleZero as 
% it assumes 2 poles and 2 zeros

subplot(221)
zplane(zer,poles);  % plot poles and zeros

% get complex H at 1000 points, assuming Fs=1000;
Fs=1000;
[H,f] = freqz(b,a,1001, 1000);

% now plot mag and phase
subplot(222), plot(f,abs(H))
grid on
xlabel('Frequency, Hz (Fs=1kHz)')
ylabel('|H|^2')
subplot(223), plot(f,unwrap(angle(H)))
grid on
xlabel('Frequency, Hz')
ylabel('phase(H),radians')

[Gd,fgd]=grpdelay(b,a,1001,Fs);

subplot(224), plot(fgd,Gd)
grid on
xlabel('Frequency, Hz')
ylabel('grd(H), samples')
xlim([0 fgd(end)])
boldify


